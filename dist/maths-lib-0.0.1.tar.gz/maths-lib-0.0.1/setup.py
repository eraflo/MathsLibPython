from  setuptools import setup

setup(
    name='maths-lib',
    version='0.0.1',
    description='My implementation of maths functions',
    packages=['libmath'],
)