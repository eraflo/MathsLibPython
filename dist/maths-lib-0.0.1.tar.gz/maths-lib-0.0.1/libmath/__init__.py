from .Module_Arithmetique import *
from .Module_Stat2Var import *
from .Module_StatistiqueDeTest import *

version = "1.0.0"